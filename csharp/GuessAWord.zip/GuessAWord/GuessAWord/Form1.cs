﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessAWord
{
    public partial class Form1 : Form
    {
        string[] words = { "dog", "cat", "mouse", "elephant", "wolf", "house", "street", "mansion" };
        string guessWord = String.Empty;
        //Random rnd = new Random();
        //int randomNumber = rnd.Next(0, words.Length - 1);
        // guessWord = words[randomNumber];
        Random number = new Random();
        StringBuilder HiddenWordBuilder = new StringBuilder();
        public Form1()
        {
            
            InitializeComponent();
        }

        public void btnStart_Click(object sender, EventArgs e)
        {
            guessWord = words[number.Next(0, words.Length)];
            HiddenWordBuilder.Append(string.Empty.PadLeft(guessWord.Length, '*'));
            lblWord.Text = "The word is: " + HiddenWordBuilder.ToString() + " Debug: Word is " + guessWord;
        }

        public void btnGuess_Click(object sender, EventArgs e)
        {
            //Attempt 3
            char letter = (Convert.ToChar(txtEntry.Text));
            for (int x = 0; x < guessWord.Length; x++)
            {
                // if (txtEntry.Text == words[x])
                // if (letter == words[Convert.ToInt32(number)][x])
                // if (letter == guessWord[x])
                if (letter == HiddenWordBuilder[x])
                {
                    HiddenWordBuilder[x] = letter;
                    lblWord.Text = HiddenWordBuilder.ToString();
                    //guesssWord[x] = txtEntry.Text;
                    lblResult.Text = "Yes! " + txtEntry.Text + " is part of the word.";
                    lblResult.Visible = true;
                }

                else
                {
                    lblResult.Text = "Invalid Entry. Please try again.";
                    lblResult.Visible = true;
                }

            }
        }
    }
}
