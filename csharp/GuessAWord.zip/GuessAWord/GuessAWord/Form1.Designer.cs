﻿namespace GuessAWord
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.btnGuess = new System.Windows.Forms.Button();
            this.txtEntry = new System.Windows.Forms.TextBox();
            this.lblWord = new System.Windows.Forms.Label();
            this.lblGuessLetter = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(29, 105);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnGuess
            // 
            this.btnGuess.Location = new System.Drawing.Point(143, 105);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(75, 23);
            this.btnGuess.TabIndex = 1;
            this.btnGuess.Text = "Guess";
            this.btnGuess.UseVisualStyleBackColor = true;
            // 
            // txtEntry
            // 
            this.txtEntry.Location = new System.Drawing.Point(184, 61);
            this.txtEntry.MaxLength = 1;
            this.txtEntry.Name = "txtEntry";
            this.txtEntry.Size = new System.Drawing.Size(34, 20);
            this.txtEntry.TabIndex = 2;
            // 
            // lblWord
            // 
            this.lblWord.AutoSize = true;
            this.lblWord.Location = new System.Drawing.Point(69, 35);
            this.lblWord.Name = "lblWord";
            this.lblWord.Size = new System.Drawing.Size(65, 13);
            this.lblWord.TabIndex = 3;
            this.lblWord.Text = "The word is:";
            // 
            // lblGuessLetter
            // 
            this.lblGuessLetter.AutoSize = true;
            this.lblGuessLetter.Location = new System.Drawing.Point(69, 61);
            this.lblGuessLetter.Name = "lblGuessLetter";
            this.lblGuessLetter.Size = new System.Drawing.Size(75, 13);
            this.lblGuessLetter.TabIndex = 4;
            this.lblGuessLetter.Text = "Guess a letter:";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(50, 160);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(103, 13);
            this.lblResult.TabIndex = 5;
            this.lblResult.Text = "This is the result text";
            this.lblResult.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 205);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblGuessLetter);
            this.Controls.Add(this.lblWord);
            this.Controls.Add(this.txtEntry);
            this.Controls.Add(this.btnGuess);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "Guess A Word";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.TextBox txtEntry;
        private System.Windows.Forms.Label lblWord;
        private System.Windows.Forms.Label lblGuessLetter;
        private System.Windows.Forms.Label lblResult;
    }
}

