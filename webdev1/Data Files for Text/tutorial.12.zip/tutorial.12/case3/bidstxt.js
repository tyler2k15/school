/*
   New Perspectives on HTML, CSS, and JavaScript
   Tutorial 12
   Case Problem 3

   Author:  
   Date:    

   Filename: bids.js

   Function List:
   
   writeBid()
      Writes the array of bids to the textarea box, starting with the most recent
      bid first.

   addBid()
      Adds a new bid to the array of bids, including the time and value of the bid

   removeBid()
      Removes the latest bid from the top of the bids array stack



*/


