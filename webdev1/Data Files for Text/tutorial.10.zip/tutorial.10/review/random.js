/*
   New Perspectives on HTML and CSS
   Tutorial 10
   Review Assignment


   Function List:
   randomInteger()
      Used to reverse the order of characters in a text string

*/


function randomInteger(size) {
   return Math.floor((size+1)*Math.random());
}