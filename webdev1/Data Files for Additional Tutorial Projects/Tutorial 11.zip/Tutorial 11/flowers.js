/*


   Function List:
   displayBanner(currentDate)
      Using the date, sets the banner image source
   calcDaysToSale(currentDate)
      Returns the days to sale message

*/


function displayBanner(currentDate) {




}


function calcDaysToSale(currentDate) {




}