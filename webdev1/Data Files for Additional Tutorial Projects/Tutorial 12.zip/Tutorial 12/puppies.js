

var puppyPics = new Array();
var pictureDesc = new Array();
var pictureDate = new Array();

puppyPics[0] = "AllTheKids.jpg";
puppyPics[1] = "susie.jpg";
puppyPics[2] = "princess.jpg";
puppyPics[3] = "wicketAndCarlos.jpg";
puppyPics[4] = "wicketAndGeorge.jpg";

pictureDesc[0] = "This is all the new puppies together. They are so cute! I just want to hold them all.";
pictureDesc[1] = "A friend held Susie up so that you can get a good look at her face. She looks just like her mom.";
pictureDesc[2] = "This is Princess, she is the same color as her brother Wicket. She loves to just give kisses to everyone who holds her.";
pictureDesc[3] = "Wicket is a very social puppy. He's not even afraid of Carlos who is my brother's dog.";
pictureDesc[4] = "Finally, here is Wicket and George. I like how they are starting to play together. They will be running around the yard in no time";

pictureDate[0] = "March 10, 2012";
pictureDate[1] = "March 10, 2012";
pictureDate[2] = "March 10, 2012";
pictureDate[3] = "March 15, 2012";
pictureDate[4] = "March 15, 2012";
